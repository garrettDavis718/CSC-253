﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarLibrary;
using System.Windows.Forms;

namespace CarClass
{
    /*8/29/21
    *CSC 253
    *Garrett Davis
    *This program will create a car object the user can manipulate the name/year/speed of the object
    */
    public partial class CarSpeed : Form
    {
        //We initialize this newCar Car object at the top in order for it to be able to be accessed by the rest of our form 
        Car newCar = new Car();
        public CarSpeed()
        {
            //Start the application
            InitializeComponent();   
        }

        //AccelerateButton is being clicked and it inputs our the data from our text boxes into the newCar object
        private void accelerateButton_Click_1(object sender, EventArgs e)
        {
            //assigning the make of the vehicle
            newCar.Make = makeBox.Text;
            //assigning the year of the vehicle
            newCar.Year = yearBox.Text;
            //Call our AccelerateClass
            newCar.Accelerate();
            //Change the readonly speed text box(speedBox) to the current speed
            speedBox.Text = Convert.ToString(newCar.Speed);
            //Print the year, make, and model into our outputbox1
            outputBox1.Items.Add("Your " + newCar.Year + " " + newCar.Make + " is currently traveling " +
                newCar.Speed + "mph.");

        }
        //BrakeButton click calls our Brake method from the Car class
        private void brakeButton_Click(object sender, EventArgs e)
        {
            //Brake method is called
            newCar.Brake();
            //Output our current speed into speedBox
            speedBox.Text = Convert.ToString(newCar.Speed);
            outputBox1.Items.Add("Your " + newCar.Year + " " + newCar.Make + " is currently traveling " +
                newCar.Speed + "mph.");
        }
        //close button
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
