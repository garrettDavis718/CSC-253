﻿using System;
using System.Collections.Generic;
using System.Text;
//my car class which holds the car object as well as its properties and the methods that will be used in our program
namespace CarLibrary
{
    public class Car
    {
        //setup our backing fields
        private string _make;
        private string _year;
        private int _speed;
        //our constructor that requires make and year to create the car
        //this constructor also starts our speed at the default (0)
        public Car(string make, string year)
        {
            _make = make;
            _year = year;
            _speed = 0;
        }
        //Default constructor that has no requirements in order to create a car object
        public Car()
        {
            _make = Make;
            _year = Year;
            _speed = 0;

        }
        //this is our make property
        public string Make
        {
            get { return _make; }
            set { _make = value; }

        }
        //this is our year property
        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }
        //Speed property
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        //This method can be called in order to increase the current vehicles speed by 5
        public void Accelerate()
        {
           _speed += 5;
   
        }
        //THis method can be called in order to decrease the current car's speed by 5, unless it is already at 0
        public void Brake()
        {
            if (_speed < 1)
            { _speed = 0; }
            else _speed -= 5;
        }
    }
}
