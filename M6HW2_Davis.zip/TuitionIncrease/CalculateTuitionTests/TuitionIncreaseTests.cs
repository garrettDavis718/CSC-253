﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CalculateTuition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculateTuition;
namespace CalculateTuition.Tests
{
    [TestClass()]
    public class TuitionIncreaseTests
    {
        [TestMethod()]
        public void increaseTuitionTest()
        {
            double input = 100;
            double expected = 102.00;
            input = TuitionIncrease.increaseTuition(input);
            
            Assert.AreEqual(input, expected);
        }
    }
}