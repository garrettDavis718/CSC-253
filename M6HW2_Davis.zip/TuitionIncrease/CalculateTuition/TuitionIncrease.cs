﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateTuition
{
    public class TuitionIncrease
    {
        public static double increaseTuition(double input)
        {
            input += (input * .02);
            return input;
        }
    }
}
