﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    static class Program
    {
        /**
        * 11/13/2021
        * CSC 253
        * Garrett Davis
        * This program will calculate the increase in tuition (.02%) of the user's input amount
        * over 5 years.
        */
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
