﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AreaClass
{
    public class Area
    {
        //First version of the CalculateArea method requires only one entry of the circle's radius
        public static double CalculateArea(double radius)
        {
            //calculating the area of the circle with the user's input
            double area = Math.PI * (radius * radius);
            
            return area;
        }
        //This is the second overload of the method that is used for rectangles, requires length and width
        public static double CalculateArea(double length, double width)
        {
            //calculate area
            double area = length * width;
            return area;
        }
        //Thir overload that requires a third entry, this is only noticeable to the programmer as it still only requires one radius input, just a different button press
        public static double CalculateArea(double radius, double height, double radius2)
        {
            //calculate the area of the cylinder
            double area = (Math.PI * (radius * radius2)) * height;
            return area;
        }
    }
}
