﻿
namespace AreaClassProgram
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLbl = new System.Windows.Forms.Label();
            this.CircleButton = new System.Windows.Forms.Button();
            this.RectangleButton = new System.Windows.Forms.Button();
            this.CylinderButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.circleRadiusBox = new System.Windows.Forms.TextBox();
            this.rectangleWidthBox = new System.Windows.Forms.TextBox();
            this.rectangleLengthBox = new System.Windows.Forms.TextBox();
            this.cylinderRadiusBox = new System.Windows.Forms.TextBox();
            this.cylinderHeightBox = new System.Windows.Forms.TextBox();
            this.circleOutputBox = new System.Windows.Forms.TextBox();
            this.rectangleOutputBox = new System.Windows.Forms.TextBox();
            this.cylinderOutputBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nameLbl.Location = new System.Drawing.Point(325, 9);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(137, 25);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Area Program";
            this.nameLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CircleButton
            // 
            this.CircleButton.Location = new System.Drawing.Point(69, 83);
            this.CircleButton.Name = "CircleButton";
            this.CircleButton.Size = new System.Drawing.Size(133, 25);
            this.CircleButton.TabIndex = 1;
            this.CircleButton.Text = "Calculate Circle Area";
            this.CircleButton.UseVisualStyleBackColor = true;
            this.CircleButton.Click += new System.EventHandler(this.CircleButton_Click);
            // 
            // RectangleButton
            // 
            this.RectangleButton.Location = new System.Drawing.Point(69, 143);
            this.RectangleButton.Name = "RectangleButton";
            this.RectangleButton.Size = new System.Drawing.Size(133, 42);
            this.RectangleButton.TabIndex = 2;
            this.RectangleButton.Text = "Calculate Rectangle Area";
            this.RectangleButton.UseVisualStyleBackColor = true;
            this.RectangleButton.Click += new System.EventHandler(this.RectangleButton_Click);
            // 
            // CylinderButton
            // 
            this.CylinderButton.Location = new System.Drawing.Point(69, 220);
            this.CylinderButton.Name = "CylinderButton";
            this.CylinderButton.Size = new System.Drawing.Size(133, 42);
            this.CylinderButton.TabIndex = 3;
            this.CylinderButton.Text = "Calculate Cylinder Area";
            this.CylinderButton.UseVisualStyleBackColor = true;
            this.CylinderButton.Click += new System.EventHandler(this.CylinderButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(173, 329);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(161, 34);
            this.ClearButton.TabIndex = 4;
            this.ClearButton.Text = "Clear Entries";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(400, 329);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(161, 34);
            this.ExitButton.TabIndex = 5;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // circleRadiusBox
            // 
            this.circleRadiusBox.Location = new System.Drawing.Point(354, 85);
            this.circleRadiusBox.Name = "circleRadiusBox";
            this.circleRadiusBox.Size = new System.Drawing.Size(87, 23);
            this.circleRadiusBox.TabIndex = 6;
            // 
            // rectangleWidthBox
            // 
            this.rectangleWidthBox.Location = new System.Drawing.Point(304, 154);
            this.rectangleWidthBox.Name = "rectangleWidthBox";
            this.rectangleWidthBox.Size = new System.Drawing.Size(87, 23);
            this.rectangleWidthBox.TabIndex = 7;
            // 
            // rectangleLengthBox
            // 
            this.rectangleLengthBox.Location = new System.Drawing.Point(400, 154);
            this.rectangleLengthBox.Name = "rectangleLengthBox";
            this.rectangleLengthBox.Size = new System.Drawing.Size(87, 23);
            this.rectangleLengthBox.TabIndex = 8;
            // 
            // cylinderRadiusBox
            // 
            this.cylinderRadiusBox.Location = new System.Drawing.Point(304, 220);
            this.cylinderRadiusBox.Name = "cylinderRadiusBox";
            this.cylinderRadiusBox.Size = new System.Drawing.Size(87, 23);
            this.cylinderRadiusBox.TabIndex = 9;
            // 
            // cylinderHeightBox
            // 
            this.cylinderHeightBox.Location = new System.Drawing.Point(400, 220);
            this.cylinderHeightBox.Name = "cylinderHeightBox";
            this.cylinderHeightBox.Size = new System.Drawing.Size(87, 23);
            this.cylinderHeightBox.TabIndex = 10;
            // 
            // circleOutputBox
            // 
            this.circleOutputBox.Location = new System.Drawing.Point(583, 83);
            this.circleOutputBox.Name = "circleOutputBox";
            this.circleOutputBox.ReadOnly = true;
            this.circleOutputBox.Size = new System.Drawing.Size(143, 23);
            this.circleOutputBox.TabIndex = 11;
            // 
            // rectangleOutputBox
            // 
            this.rectangleOutputBox.Location = new System.Drawing.Point(583, 154);
            this.rectangleOutputBox.Name = "rectangleOutputBox";
            this.rectangleOutputBox.ReadOnly = true;
            this.rectangleOutputBox.Size = new System.Drawing.Size(143, 23);
            this.rectangleOutputBox.TabIndex = 12;
            // 
            // cylinderOutputBox
            // 
            this.cylinderOutputBox.Location = new System.Drawing.Point(583, 220);
            this.cylinderOutputBox.Name = "cylinderOutputBox";
            this.cylinderOutputBox.ReadOnly = true;
            this.cylinderOutputBox.Size = new System.Drawing.Size(143, 23);
            this.cylinderOutputBox.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(375, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "Radius";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(325, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 15);
            this.label2.TabIndex = 15;
            this.label2.Text = "Radius";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(419, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 15);
            this.label3.TabIndex = 16;
            this.label3.Text = "Height";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(420, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 15);
            this.label4.TabIndex = 17;
            this.label4.Text = "Width";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(328, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 18;
            this.label5.Text = "Length";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(622, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 15);
            this.label6.TabIndex = 19;
            this.label6.Text = "Circle Area";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(612, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 15);
            this.label7.TabIndex = 20;
            this.label7.Text = "Rectangle Area";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(612, 202);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 15);
            this.label8.TabIndex = 21;
            this.label8.Text = "Cylinder Area";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cylinderOutputBox);
            this.Controls.Add(this.rectangleOutputBox);
            this.Controls.Add(this.circleOutputBox);
            this.Controls.Add(this.cylinderHeightBox);
            this.Controls.Add(this.cylinderRadiusBox);
            this.Controls.Add(this.rectangleLengthBox);
            this.Controls.Add(this.rectangleWidthBox);
            this.Controls.Add(this.circleRadiusBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.CylinderButton);
            this.Controls.Add(this.RectangleButton);
            this.Controls.Add(this.CircleButton);
            this.Controls.Add(this.nameLbl);
            this.Name = "Form1";
            this.Text = "asd";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Button CircleButton;
        private System.Windows.Forms.Button RectangleButton;
        private System.Windows.Forms.Button CylinderButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.TextBox circleRadiusBox;
        private System.Windows.Forms.TextBox rectangleWidthBox;
        private System.Windows.Forms.TextBox rectangleLengthBox;
        private System.Windows.Forms.TextBox cylinderRadiusBox;
        private System.Windows.Forms.TextBox cylinderHeightBox;
        private System.Windows.Forms.TextBox circleOutputBox;
        private System.Windows.Forms.TextBox rectangleOutputBox;
        private System.Windows.Forms.TextBox cylinderOutputBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

