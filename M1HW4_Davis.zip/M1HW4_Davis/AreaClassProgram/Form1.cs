﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using AreaClass;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaClassProgram
{
    /*
     * 8/29/21  
     * CSC 253
     * Garrett Davis
     * This program will calculate the area of various shapes, depending on which button the user hits and their input
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CircleButton_Click(object sender, EventArgs e)
        {
            //init. varible we will be using to hold our radius entry
            double radius;
            //convert our radius entry to double
            double.TryParse(circleRadiusBox.Text, out radius);
            //init. varible and call our calculatearea method that we use for circle(requiring only a radius input)
            double calculation = Area.CalculateArea(radius);
            //convert our area to text and put it into our output box
            circleOutputBox.Text = Convert.ToString(calculation);
            
        }
        

        private void RectangleButton_Click(object sender, EventArgs e)
        {
            //init. variable for length and width to be used in our CalculateArea variable
            double length;
            double width;
            //convert our input from text to double and put them into our variables
            double.TryParse(rectangleWidthBox.Text, out width);
            double.TryParse(rectangleLengthBox.Text, out length);
            //call our CalculateArea method with the length and width parameters
            double calculation = Area.CalculateArea(length, width);
            //convert our returned calculation and output it
            rectangleOutputBox.Text = Convert.ToString(calculation);
        }

        private void CylinderButton_Click(object sender, EventArgs e)
        {
            //init. varibles for our method
            double radius;
            double height;
            //convert our input to double and put into variables
            double.TryParse(cylinderRadiusBox.Text, out radius);
            double.TryParse(cylinderHeightBox.Text, out height);
            //call our method with our radius, height, then our radius a second time, this just ensures we get the correct iteration of our method
            double calculation = Area.CalculateArea(radius, height, radius);
            //convert and output our calculation
            cylinderOutputBox.Text = Convert.ToString(calculation);

        }
        //button for deleting all input and output
        private void ClearButton_Click(object sender, EventArgs e)
        {
            //empty all text boxes
            circleRadiusBox.Text = "";
            circleOutputBox.Text = "";
            rectangleLengthBox.Text = "";
            rectangleWidthBox.Text = "";
            rectangleOutputBox.Text = "";
            cylinderRadiusBox.Text = "";
            cylinderHeightBox.Text = "";
            cylinderOutputBox.Text = "";
        }
        private void ExitButton_Click(object sender, EventArgs e)
        {
            //close program
            this.Close();
        }

       
    }
}
