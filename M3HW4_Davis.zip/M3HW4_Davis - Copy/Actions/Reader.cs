﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Actions
{
    //reader class that will read the "UserInformation.csv" file and add the different person objects to the people list
    public static class Reader
    {
        public static string ReadFile()
        {   //init streamReader obj 
            StreamReader InputFile;
            //try/catch
            try
            {
                //open the file
                InputFile = File.OpenText("UserInformation.csv");
                //while loop to ensure that we only read where is needed(not whitespace)
                while (!InputFile.EndOfStream)
                {
                    //init age for conversion later
                    int age;
                    //tokenize our inputFile, with individual lines and splitting at our commas
                    string[] token = InputFile.ReadLine().Split(',');
                    //convert the age input and output it to the age variable
                    int.TryParse(token[2], out age);
                    //Add our new person to our people list
                    AddToList.createList(token[0], token[1], age);
                }
                //return positive message to show user we were successful
                return "loaded";
            }
            //exception message catch
            catch (Exception ex)
            { 
                string message = ex.Message;
                return message;
            }
        }

    }
}
