﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actions
{
    //List class to hold our people list
    public static class Lists
    {
        public static List<Person> people = new List<Person>();
    }
}
