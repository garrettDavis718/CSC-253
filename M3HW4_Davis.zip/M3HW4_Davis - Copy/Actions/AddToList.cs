﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actions
{
    public static class AddToList
    {
        //AddToList class that hold our method for adding a new person to our lists.people list
        public static void createList(string firstName, string lastName, int age)
        {
            Lists.people.Add(new Person(firstName, lastName, age));
        }
    }
}
