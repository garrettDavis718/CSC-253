﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Actions;
/**
* 9/23/2021
* CSC 253
* Garrett Davis
* This program will read from the "UserInformation.csv" file and 
* tokenize the lines from that file into objects and add them to a list
* It will then show the user the different person objects from that file
*/

namespace ReadClassInformationFromFile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Load button that will read the file and output the information for the user to see
        private void LoadButton_Click(object sender, EventArgs e)
        {
            //Create a message to tell the user if they were successful in reading the file
            string message = Reader.ReadFile();
            MessageBox.Show(message);
            //foreach loop that will add each person's first, last, and age to our output listbox
            foreach (Person person in Lists.people)
            {
                outputBox.Items.Add(person.FirstName + " " + person.LastName + " " + person.Age);
            }
        }
        //exit button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
