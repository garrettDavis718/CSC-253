﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CalculateRetailPrice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CalculateRetailPrice.Tests
{
    [TestClass()]
    public class CalculateRetailPriceTests
    {
        [TestMethod()]

        public void CalculatePriceTest()
        {
            string initialPrice = "5";
            string markUp = "100";

            double actual = CalculateRetailPrice.CalculatePrice(initialPrice, markUp);
            double expected = 10;
            Assert.AreEqual(expected, actual);
        }
    }
}