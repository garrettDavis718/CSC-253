﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateRetailPrice
{
    public class CalculateRetailPrice
    {
        public static double CalculatePrice(string _initialPrice, string _markUp)
        {
            double initialPrice;
            double markUp;
            double.TryParse(_initialPrice, out initialPrice);
            double.TryParse(_markUp, out markUp);
            markUp *= .01;
            return initialPrice + (initialPrice * markUp);
        }
        

    }
}
