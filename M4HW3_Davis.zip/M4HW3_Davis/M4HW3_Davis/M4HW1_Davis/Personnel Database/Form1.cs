﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 10/3/21
* CSC 253
* Garrett Davis
* This program loads the personnel database and displays the employee table and sorts that table
* by pay rate, depending on which button is pressed. 
*/

namespace Personnel_Database
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void SortAscending_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByHourlyPay(this.personnelDataSet.Employee);
        }

        private void SortDescending_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByHourlyPayDesc(this.personnelDataSet.Employee);
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            string input = nameBox.Text;
            this.employeeTableAdapter.SearchName(this.personnelDataSet.Employee, input);
        }

        private void ShowAllButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);
        }
    }
}
