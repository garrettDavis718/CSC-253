﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/9/21
* CSC 253
* Garrett Davis
* This is my word counter and letter averaging program, 
* it will count the amount of words input by the user and average the letters
*/

namespace WordActions
{
    public class Words
    {
        //Our default constructor in case no input is entered
        public static string CountWords()
        {
            string output = "0";
            return output;
        }
        //create public class for counting the words
        public static double CountWords(string input)
        {
            //initialize our counter for use in our later foreach loop
            int counter = 0;
            //trim our input string and set it to a new string
            string trimmedInput = input.Trim();
            //split our trimmedInput string with null so that it uses white space as a delimeter
            string[] count = trimmedInput.Split(null);
            //verify that the trimmedInput string is indeed initialized with this if statement
            if (trimmedInput == null || trimmedInput == " ")
            {
                //keep our word counter at 0 if we do not have input
                counter = 0;
            }
            //else statement for when there is input
            else
            {
                //foreach loop that will count each "word" in our count array and increment our counter variable
                foreach (var word in count)
                {
                    //increment
                    counter++;
                }
            }

            //return the double counter to our main program
            return counter;

        }
        //initialize our method to count the letters from our input string
        public static double CountLetters(string input)
        {
            //initalize our counter int
            int counter = 0;
            //trim our input string
            string trimmedInput = input.Trim();
            //split our trimmedInput string and store the values in an array, we use null as our delimeter here to default to white space
            string[] words = trimmedInput.Split(null);
            //foreach loop that will find the length of each word in our words array and add them to our counter int
            foreach (var word in words)
            {
                //counter 
                counter += word.Length;
            }
            return counter;
        }
        //average amount of letters method
        public static double AverageLetters(double words, double letters)
        {
            //create our average double by dividing our number of letters total by the number of words total
            double average = letters / words;
            //return
            return average;
        }
    }
}

