﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using WordActions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordCounter2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalcButton_Click(object sender, EventArgs e)
        {
            //if statment that will first check if the input of the InputBox is empty or not
            if (!string.IsNullOrEmpty(this.inputBox.Text))
            {
                //pass the input from our inputBox as string
                string input = inputBox.Text;
                //input the string parameter "input" into our wordcounter and set it to our string wordsCounted
                double wordsCounted = Words.CountWords(input);
                //inplement our number counter method to count how many letters we have in our input box altogether
                double lettersCounted = Words.CountLetters(input);
                //call our averageLetters program with our already found word count and lettercount
                double averageLetters = Words.AverageLetters(wordsCounted, lettersCounted);
                //Output our results
                WordCountLbl.Text = Convert.ToString(wordsCounted);
                //This .ToString method works to restrict my averageLetters double to two decimal places
                AverageLetterLbl.Text = averageLetters.ToString("N2");
            }
            //If the InputBox is empty it will return 0 as the amount of words
            else
            {
                string wordsCounted = Words.CountWords();
                WordCountLbl.Text = wordsCounted;
                //hard coding this because it isn't being referenced from here
                AverageLetterLbl.Text = "0";
            }


        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            //hard coding our different labels and textboxes with empty inputs
            inputBox.Text = "";
            WordCountLbl.Text = "0";
            AverageLetterLbl.Text = "0";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
