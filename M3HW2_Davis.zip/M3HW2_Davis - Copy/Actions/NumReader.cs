﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Actions
{
    public class NumReader
    {
        //method to create a list from our RandomNumberText.Txt
        public static List<string> CreateList()
        {
            //init our StreamReader object inputFile
            StreamReader inputFile;
            //Open our file
            inputFile = File.OpenText("RandomNumberText.Txt");
            //Manipulate our file, I found this little snippet of code online for reading all
            //lines in my RandomNumberText file and then sending them to a list
            List<string> numList = File.ReadAllLines("RandomNumberText.Txt").ToList();
            //close our file
            inputFile.Close();
            //return our list
            return numList;
        }
        //Count our list with this method
        public static int CountNumbers(List<string> numList)
        {
            int howManyNumbers = numList.Count;
            return howManyNumbers;
        }
        //method for converting each num in our list to an int and adding it to a running sum
        public static int SumNumbers(List<string> numList)
        {
            //init sum
            int sum = 0;
            //foreach loop that will get each number(string) in numlist
            foreach (string num in numList)
            {
                //init number int
                int number;
                //tryparse num
                int.TryParse(num, out number);
                //add it to running sum
                sum += number;
            }
            return sum;
        }
    }
}
