﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Actions;
/**
* 9/19/21
* CSC 253
* Garrett Davis
* This program will read the numbers from RandomNumberText.Txt and give the count and sum of them to the user
*/
namespace RandomNumberReader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //import numbers button for our main objective
        private void ImportButton_Click(object sender, EventArgs e)
        {
            //try catch for streamreader, just in case
            try 
            {
                //Create our numList with my CreeatList method
                List<string> numList = NumReader.CreateList();
                //initialize and set howManyNumbers int with my CountNumbers method
                int howManyNumbers = NumReader.CountNumbers(numList);
                //initialize and set sum int wiht my SumNumbers Method
                int sum = NumReader.SumNumbers(numList);
                //convert and output for user
                countBox.Text = Convert.ToString(howManyNumbers);
                sumBox.Text = Convert.ToString(sum);
            }
            //exception method for our trycatch
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        //close button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
