﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Actions;
using System.Windows.Forms;
/**
* 9/12/21
* CSC 253
* Garrett Davis
* This Program will space the user's input out by adding a space after every upper cased letter. 
*/
namespace WordSeperator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //SeparateButton that will run our wordseparator program
        private void SeparateButton_Click(object sender, EventArgs e)
        {
            //get our input
            string _input = InputBox.Text;
            //trim input and store it
            string input = _input.Trim();
            //run our WordSeparator method with our input as the parameter and set the results to the output string for later use
            string output = Word.WordSeparator(input);
            //put our output in the textbox 
            InputBox.Text = output;
        }
        //Button for clearing textbox
        private void ClearButton_Click(object sender, EventArgs e)
        {
            InputBox.Text = "";
        }
        //Close Button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
