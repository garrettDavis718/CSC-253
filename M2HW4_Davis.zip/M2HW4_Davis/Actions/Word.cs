﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actions
{
    public class Word
    {
        //method for separating words
        public static string WordSeparator(string input)
        {
            //init our output string and leave it empty;
            string output = "";
            //if statement to make sure that the user has put in some input so that the program doesn't crash trying do our foreach loop
            if (!string.IsNullOrEmpty(input))
            {
                //foreach loop, checks each char in input string
                foreach (char letter in input)
                {
                    //for each letter we will run an if statement to check if it is a letter, upper-cased, and not at the index of 0(first letter in string)
                    if (char.IsLetter(letter) && char.IsUpper(letter) && (input.IndexOf(letter) != 0))
                    {
                        //if it passes we will add a space and then the letter to our output string.
                        output += " " + letter.ToString();
                    }
                    //else(if the letter isn't a letter, upper-cased, or at the index of 0) we will just add the letter to our output string
                    else
                    {
                        //adds the letter, after converting it to string
                        output += letter.ToString();
                    }
                }
                //return our output string after going through every char 
                return output;
            }
            //else statement in case we do have an empty box so we don't have any crashing because of it
            else
            {
                //uses the textbox as a messageBox
                output = "Please enter text in the textbox with no spacing and capitalizing every word.";
                //returns this message for the textBox to print, making sure to always have a return
                return output;
            }
        }
    }
}
