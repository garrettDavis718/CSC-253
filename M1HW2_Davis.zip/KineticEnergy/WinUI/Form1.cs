﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 8/20/21
* CSC 253
* Garrett Davis
* Program will take the user's input of the mass and velocity of an object.
* The program will output the kinetic energy of the object. 
*/


namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double m;
            double v;

            if (double.TryParse(massTextBox.Text, out m) && double.TryParse(velocityTextBox.Text, out v))
            {
                double KE = KineticEnergy(m, v);
                kineticEnergyTextBox.Text = KE.ToString("n");
            }
            else
            {
                MessageBox.Show("Please enter valid numbers", "Invalid input");
            }

        }

        private double KineticEnergy(double m, double v)
        {
            double KE = 0.5 * m * Math.Pow(v, 2);
            return KE;
        }
    }
}
