﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 8/20/2021
* CSC 253
* Garrett Davis
* This program shows a conversion of 1-20 celsius to fahrenheit
*/
namespace WinUi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //button click starts the program's function
        private void button1_Click(object sender, EventArgs e)
        {
            //initialize constants for our  calculation
            const int MIN_TEMPERATURE = 0;
            const int MAX_TEMPERATURE = 20;
            //initialize variable for fahrenheit
            decimal fahrenheit;
            //This line adds a "header" to our outputBox's "table", cannot be put in our for loop 
            outputBox.Items.Add("         Celsius      Fahrenheit");
            //For loop to calculate each temperature individually and print the results. 
            for (int c = MIN_TEMPERATURE; c <= MAX_TEMPERATURE; c++)
            {
                //Main calculation which calculates the fahrenheit temperature from the celsius input "c"
                fahrenheit = (9m / 5m) * c + 32;
                //Prints both tempreatures with a tab in between for readability
                outputBox.Items.Add("\t" + c + "\t" + fahrenheit);
            }
        }
        //exit button
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
