﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeData;

namespace Employee_Classes
{
    public partial class TeamLeaderForm : Form
    {
        public TeamLeaderForm()
        {
            InitializeComponent();
        }

        private void EnterTeamLeaderBtn_Click(object sender, EventArgs e)
        {
            string name = NameTxtBox.Text;
            int employeeNumber;
            int.TryParse(NumberTxtBox.Text, out employeeNumber);
            double bonus;
            double.TryParse(MonthlyBonusTxtBox.Text, out bonus);
            double reqHours;
            double.TryParse(ReqTrainingTxtBox.Text, out reqHours);
            double trainedHours;
            double.TryParse(HoursTrainedTxtBox.Text, out trainedHours);
            TeamLeader input = new TeamLeader(name, employeeNumber, bonus, reqHours, trainedHours);
            outputBox.Items.Add("Employee Name: " + input.Name);
            outputBox.Items.Add("Employee Number: " + input.EmployeeNumber);
            outputBox.Items.Add("Monthly Bonus: $" + input.BonusAmount);
            outputBox.Items.Add("Required Training Hours: " + input.RequiredHours);
            outputBox.Items.Add("Hours already trained: " + input.TrainedHours);
        }

        private void ClearTxtBtn_Click(object sender, EventArgs e)
        {
            NameTxtBox.Clear();
            NumberTxtBox.Clear();
            MonthlyBonusTxtBox.Clear();
            ReqTrainingTxtBox.Clear();
            HoursTrainedTxtBox.Clear();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.ShowDialog();
        }
    }
}
