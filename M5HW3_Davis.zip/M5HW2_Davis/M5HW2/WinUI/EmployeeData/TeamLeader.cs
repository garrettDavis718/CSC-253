﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeData
{
    public class TeamLeader : Employee
    {
        public double BonusAmount { get; set; }
        public double RequiredHours {get; set;}
        public double TrainedHours { get; set; }
        public TeamLeader(string name, int employeeNumber, double bonusAmount, double requiredHours, double trainedHours)
            : base(name, employeeNumber)
        {
            BonusAmount = bonusAmount;
            RequiredHours = requiredHours;
            TrainedHours = trainedHours;
        }
    }
}
