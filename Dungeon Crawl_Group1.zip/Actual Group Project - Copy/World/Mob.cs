﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    //Mob class
    public class Mob
    {
        //properties
        private string _mobId;
        private string _name;
        private double _healthPoints;
        private double _manaPoints;
        private string _desc;
        //initialize list of all mobs in game
        public List<Mob> mobList = new List<Mob>()
        {
            new Mob("001", "Dog", 100, 100, "A friendly companion."),
            new Mob("002", "Mutant", 25, 10, "A dangerous, mutated enemy."),
            new Mob("003", "Skeleton", 10, 100, "A very spooky skeleton enemy."),
            new Mob("004", "Granny", 15, 200, "A friendly, but dangerous looking older lady."),
            new Mob("005", "Merchant", 400, 400, "A merchant with a very shiny gun on his hip.")
        };
        //constructor
        public Mob(string mobId, string name, double healthPoints, double manaPoints, string desc)
        {
            _mobId = mobId;
            _name = name;
            _healthPoints = healthPoints;
            _manaPoints = manaPoints;
            _desc = desc;
        }
        //properties
        public string MobId
        {
            get { return _mobId; }
            set { _mobId = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public double HealthPoints
        {
            get { return _healthPoints; }
            set { _healthPoints = value; }
        }
        public double ManaPoints
        {
            get { return _manaPoints; }
            set { _manaPoints = value; }
        }
        public string Desc
        {
            get { return Desc; }
            set { _desc = value; }
        }
    }
}
