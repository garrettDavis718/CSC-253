﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    public class Menu
    {
        //GreetUser Menu for greeting a first time user
        public static void GreetUser()
        {
            Console.WriteLine("Thank you for playing my game, this is the first iteration of it so it is still fairly simple. (enter to continue)");
            Console.ReadLine();
            Console.WriteLine("For now you will be able to go on a tour of the world we have created thus far.");
            Console.ReadLine();
            Console.WriteLine("Just type 'North' or 'N' to move throughout our world");
            Console.ReadLine();
            Console.WriteLine("Do not worry about capitalization for movement.");
        }
        //This is our menu to get our player, this returns a PlayerCharacter object with a name, race, class, and validated password
        public static PlayerCharacter GetPlayer()
        {
            //Start by asking for name
            Console.WriteLine("What is your name? ");
            //initialize variable and assign
            string userName = Console.ReadLine();
            //initialize password
            string password;
            //set our variable for our while loop
            int keepGoing;
            //do while to run it at least once
            do { 
                //Prompt user for password
                Console.WriteLine("What is your password? ");
                //assign password
                password = Console.ReadLine();
                //Run our uppercase tester method on our password string, this will give us a true or false dending on the user's password input
                bool upperTest = TestUpper(password);
                //Run lowercase tester method, same way
                bool lowerTest = TestLower(password);
                //Run Special character test to see if the password string contains as special character
                bool specialTest = TestSpecial(password);
                //Call final testing method that will let the user know if they're password has some sort of issue, this will tell the user what is wrong with their
                //particular entry
                bool passwordTest = TestPassword(upperTest, lowerTest, specialTest);
                //This is just a short if statement to make our tests run again if they are failed the first time
                if (passwordTest == true)
                {
                    keepGoing = 1;
                }
                //assign 0 to our keepGoing variable to end the do while loop
                else keepGoing = 0;
            } while (keepGoing == 0);
            //Prompt for user's character's race(not currently validated, need to set races)
            Console.WriteLine("Please enter your character's race: ");
            string characterRace = Console.ReadLine();
            //Prompt for user's character's class(not currently validated, need to set classes)
            Console.WriteLine("Please enter your character's class: ");
            string characterClass = Console.ReadLine();
            //initialize our current user as a playerCharacter object
            PlayerCharacter user;
            user = new PlayerCharacter(userName, password, characterRace, characterClass );
            //return the user's created character;
            return user;
    
        }
        //Method for testing if theirs an upper-cased letter in a string, used for password validation
        public static bool TestUpper(string password)
        {
            //set a bool for return
            bool testResults;
            //counter that will count everytime an uppercased letter is used in our string, if we have at least one, the bool should return true
            int counter = 0;
            foreach (char letter in password)
            {
                //if uppercased letter increment our counter
                if (char.IsUpper(letter))
                {
                    counter++;
                }
                //nothing happening in else, because we do not want to manipulate counter if there isn't an uppercased letter
                else {  }
            }
            //if statment for checkign if our counter is above 0
            if (counter > 0)
            {
                testResults = true;
            }
            else
            {
                testResults = false;
            }
            //return our results based on password entry
            return testResults;
        }
        //basically the same method as before, just using char.IsLower() method
        public static bool TestLower(string password)
        {
            bool testResults;
            int counter = 0;
            foreach (char letter in password)
            {

                if (char.IsLower(letter))
                {
                    counter++;
                }
                else { }
            }
            if (counter > 0)
            {
                testResults = true;
            }
            else
            {
                testResults = false;
            }
            return testResults;
        }
        //This method will check to see if the password string contains any of the following special characters, if it does it will return a true boolean (testResults)
        public static bool TestSpecial(string password)
        {
            //set our bool variable
            bool testResults;
            //if statement to check our string for special characters
            if (password.Contains('!') || password.Contains('@') || password.Contains('#') || password.Contains('$') || password.Contains('%')
                || password.Contains('^') || password.Contains('&') || password.Contains('*') || password.Contains('(') || password.Contains('('))
            {
                testResults = true;
            }
            else
            {
                testResults = false;
            }
            //return our bool for user to see
            return testResults;


        }
        //final password tester that will each earlier test to see what needs to be changed about the user's specific input, requires all previous tests answer's as paramaters
        public static bool TestPassword(bool upper, bool lower, bool special)
        {
            //set our bool
            bool result;
            //check if our first bool is false, if so let the user know
            if (upper != true)
            {
                result = false;
                Console.WriteLine("Please enter an upper-cased letter in your password. ");
            }
            //check if second bool is false, if so let user know
            else if (lower != true)
            {
                result = false;
                Console.WriteLine("Please enter a lower-cased letter in your password.");
            }
            //chekc if third bool is false, if so let user know
            else if (special != true)
            {
                result = false;
                Console.WriteLine("Please enter a special character in your password.");
            }
            //If all bools come back true then we set our test result so we will finally set our password
            else { result = true; }
            return result;
        }
        //Menu that is seen as soon as you open our game, this will find out if your a new or returning member
        public static void EntryMenu()
        {
            //set our bool for do while statement
            bool repeat;
            //Prompt user if they've played before
            Console.WriteLine("Have you played The Last Survivors before? ");
            string decision = Console.ReadLine();
            //determine what to do with user based on input, also force entry to lower-case for easier checking
            decision = decision.ToLower();
            do
            {
                //if they have played before we go right in without explanation
                if (decision == "yes")
                {
                    PlayerCharacter user = Menu.GetPlayer();
                    Console.WriteLine("Great to see you again " + user.Name);
                    //stop the method from repeating
                    repeat = false;
                }
                //new player so they will get some direction
                else if (decision == "no")
                {
                    //Greet User with our method
                    Menu.GreetUser();
                    //Create new player;
                    PlayerCharacter user = Menu.GetPlayer();
                    //set username for future use when referring to player
                    string userName = user.Name;
                    //This method is supposed to add the new player to add the player to the current list of players, but It's not implemented correctly yet
                    //PlayerCharacter.AddNewPlayer(user);
                    //Greet user
                    Console.WriteLine("It's great to meet you " + userName + "! \n Now let's get started.");
                    //stop method from repeating
                    repeat = false;
                }
                else
                {
                    //validation for user's input, forces method to repeat
                    Console.WriteLine("Please enter yes or no: ");
                    decision = Console.ReadLine();
                    decision = decision.ToLower();
                    repeat = true;
                }
            }
            while (repeat == true);
        }
        //main menu method
        public static void MainMenu()
        {
            //show main menu to user and ask for input
            Console.WriteLine("What would you like to do?\nMove\nAttack\nLook\nExit ");
            //assign variable for decision to be used in switch statement
            string decision;
            //establish initial roomIndex number
            int roomIndex = 0;
            //set our current room
            Room currentRoom;
            //set our decision
            decision = Console.ReadLine();
            //force decision to lower for easier validation
            decision = decision.ToLower();
            //set variable keepGoing for our do While loop
            int keepGoing;
            do
            {
                //switch statement with decision string as the case
                switch (decision)
                {
                    //case move will ask user which way they would like to travel and tell them which room they've made it to
                    case "move":
                        Console.WriteLine("Which way would you like to move?\nNorth(n)\nSouth(s)");
                        string choice = Console.ReadLine();
                        roomIndex = Room.MoveRoom(roomIndex, choice);
                        currentRoom = Room.GetRoom(roomIndex);
                        Console.WriteLine("You are currently in " + currentRoom.Name);
                        Console.WriteLine("What would you like to do next? ");
                        decision = Console.ReadLine();
                        decision = decision.ToLower();
                        keepGoing = 0;
                        break;
                        //case attack will call the damage method so and print the user's damage, also it will tell the user their current room
                    case "attack":
                        currentRoom = Room.GetRoom(roomIndex);
                        int damage = Combat.Damage();
                        Console.WriteLine("You hit for a total of: " + damage);
                        Console.WriteLine("You are currently in " + currentRoom.Name);
                        Console.WriteLine("What would you like to do next? ");
                        decision = Console.ReadLine();
                        decision = decision.ToLower();
                        keepGoing = 0;
                        break;
                        //case look will show the user the description of the room
                    case "look":
                        currentRoom = Room.GetRoom(roomIndex);
                        Console.WriteLine("You are currently in " + currentRoom.Name +
                            "you see " + currentRoom.Desc);
                        Console.WriteLine("What would you like to do next? ");
                        decision = Console.ReadLine();
                        decision = decision.ToLower();
                        keepGoing = 0;
                        break;
                        //exit case ends the statment
                    case "exit":
                        keepGoing = 1;
                        break;
                        //default case for when the user misinputs
                    default:
                        Console.WriteLine("Please choose one of the following: \nMove\nAttack\nLook\nExit");
                        decision = Console.ReadLine();
                        decision = decision.ToLower();
                        keepGoing = 0;
                        break;
                }
                //while for loop
            } while (keepGoing == 0);
        }
    }
}
