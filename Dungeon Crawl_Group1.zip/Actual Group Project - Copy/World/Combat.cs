﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    //combat class that currently has the user do 0-20 damage based on a random number
    public class Combat
    {
        //Damage method
        public static int Damage()
        {
            //initialize a new random
            Random r = new Random();
            //initailize our damage integer and set it to equal a random number between 0-20
            int dmg = r.Next(0, 21);
            //return our damage
            return dmg;
        }
        //Method for getting the health of either us or a mob after they've taken damage, this method hasn't been implemented yet
        public static int GetHealth(int health, int dmg)
        {
            //initialize our newHealth variable
            int newHealth;
            //newHealth is goingto be equal to health - damage from our parameters
            newHealth = health - dmg;
            //return newHealth
            return newHealth;
        }
    }
}
