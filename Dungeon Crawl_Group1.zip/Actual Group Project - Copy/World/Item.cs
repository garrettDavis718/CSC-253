﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    //Item Class used for creating item objects and storing them in our item list, will be used in future iterations
    public class Item
    {
        //constructors
        private double _weight;
        private string _name;
        private string _desc;
        //List of all items in the game;
        public List<Item> ItemList = new List<Item>()
        {
            new Item(2, "Knife", "A small blade."),
            new Item(6, "bat", "An old metal baseball bat."),
            new Item(1, "Fedora", "A fancy hat."),
            new Item(.2, "Gold Key", "A golden key.")

        };
        //list of items held on our character, not used yet
        public List<Item> HeldItems = new List<Item>();
        //Item Custom constructor
        public Item(double weight, string name, string desc)
        {
            _weight = weight;
            _name = name;
            _desc = desc;
        }
        //Parameters
        public double Weight
        {
            get { return _weight; }
            set { _weight = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Desc
        {
            get { return _desc; }
            set { _desc = value; }
        }
        
        


    }
}
