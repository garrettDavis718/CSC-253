﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace World
{
    //room class
    public class Room
    {
        //room properties
        private string _name;
        private string _desc;
        private string _exit;
        private string _roomId;
        //room list with all rooms
        public static List<Room> RoomList = new List<Room>
        { 
            new Room("Home", "A small shack that you've built from scrap you've collected over time.", "Front Door", "001"),
            new Room("Desert", "A desolate wasteland. What is currently left of Maryland.", "Hatch to vault.", "002"),
            new Room("Vault", "A metal vault, built for the survival of humanity. Though it does not look like humanity much occupies it anymore...", "Door to tunnels", "003"),
            new Room("Tunnels", "A narrow passage for travel between vaults.", "Exit for second vault", "004"),
            new Room("Large Vault", "A vault larger than the last that is home to all of the 'more intelligent' humans", "Rocket", "005"),
            new Room("The Moon", "The final frontier, you've made it off of that hell-hole of a planet, now it is time to relax... until your oxygen expires.", "Death", "006")
        };
        //room constructor
        public Room(string name, string desc, string exit, string roomId)
        {
            _name = name;
            _desc = desc;
            _exit = exit;
            _roomId = roomId;
        }
        //default room constructor
        public Room()
        {
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Desc
        {
            get { return _desc; }
            set { _desc = value; }
        }
        public string Exit
        {
            get { return _exit; }
            set { _exit = value; }
        }
        public string RoomId
        {
            get{ return _roomId; }
            set{ _roomId = value; }
        }
        //method to get the current room based on the roomindex paramter
        public static Room GetRoom(int roomIndex)
        {
            Room currentRoom = RoomList[roomIndex];
            return currentRoom;
        }
        //method to get the current room's index based on which way the user decided to move
        public static int MoveRoom(int roomIndex, string direction)
        {
            direction = direction.ToLower();

            if ((direction == "n" || direction == "north") && roomIndex < 5)
            {
                roomIndex++;
            }
            else if ((direction == "s" || direction == "south") && roomIndex > 0)
            {
                roomIndex--;
            }
            else { };
           
            return roomIndex;
        }
        
    }
}
