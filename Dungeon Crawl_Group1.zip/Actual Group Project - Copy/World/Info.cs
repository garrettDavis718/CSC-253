﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    class Info
    {
        //Class for when the user wants information, hasn't been implemented yet, could be merged into menu class potentially
     
    }
}
