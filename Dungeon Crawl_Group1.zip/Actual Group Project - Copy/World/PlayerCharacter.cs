﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    //Playercharacter class
    public class PlayerCharacter
    {
        //properties of PC
        private string _name;
        private double _healthPoints;
        private double _armorClass;
        private string _password;
        private string _race;
        private string _characterClass;
        //list of PC's for future loading, doesn't currently work
        /*public static List<PlayerCharacter> PlayerList = new List<PlayerCharacter>
        {
        };*/
        //Constructor
        public PlayerCharacter(string name, string password, string race, string characterClass)
        {
            _name = name;
            _password = password;
            _race = race;
            _characterClass = characterClass;
        }
        public PlayerCharacter(string name, string password, double healthPoints, double armorClass)
        {
            _name = name;
            _healthPoints = healthPoints;
            _armorClass = armorClass;
            _password = password;
        }
        public PlayerCharacter(string name, string password)
        {
            _name = name;
            _password = password;
        }
        //Properties
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        public double HealthPoints
        {
            get { return _healthPoints; }
            set { _healthPoints = value; }
        }
        public double ArmorClass
        {
            get { return _armorClass; }
            set { _armorClass = value; }
        }
        public string Race
        {
            get { return _race; }
            set { _race = value; }
        }
        public string CharacterClass
        {
            get { return _characterClass; }
            set { _characterClass = value; }
        }
        //method to add new players to playerlist for later loading, not working yet
        /*public static PlayerCharacter AddNewPlayer(PlayerCharacter user)
        {
            PlayerList.Add(user);
            return user;
        }*/
        
        

    }
}
