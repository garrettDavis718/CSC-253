﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    //treasure class
    public class Treasure
    {
        //properties
        private string _treasureId;
        private string _name;
        private double _value;
        private string _desc;
        //setup treasureList for all treasure in game
        List<Treasure> treasureList = new List<Treasure>()
        {
            new Treasure("001", "Pre War Money", 5, "A currency used before the war."),
            new Treasure("002", "Broken Transistor", 20, "A broken electronic that could be worth something"),
            new Treasure("003", "Fancy Typewriter", 400, "A beautiful typewriter from the era before....")
        };
        //Constructor
        public Treasure(string treasureId, string name, double value, string desc)
        {
            _treasureId = treasureId;
            _name = name;
            _value = value;
            _desc = desc;
        }
        //properties
        public string TreasureId
        {
            get { return _treasureId; }
            set { _treasureId = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public double Value
        {
            get { return _value; }
            set { _value = value; }
        }
        public string Desc
        {
            get { return _desc; }
            set { _desc = value; }
        }

    }
}
