﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Actions
{
    public class RandomNumberGenerator
    {
        public static void CreateRandomNumberText(int howManyNumbers)
        {
            //Set our random rand
            Random rand = new Random();
            //Create our outputFile StreamWriter object
            StreamWriter outputFile;
            //Create our RandomNumberText.Txt for holding the random numbers
            outputFile = File.CreateText("RandomNumberText.Txt");
            //for loop that we generate enough random numbers(the amount requested by user)
            for (int i = 0; i < howManyNumbers; i++)
            {
                //WriteLine in our file, this is generating a random number between 1 and 100, then we are converting it to stringn
                outputFile.WriteLine(Convert.ToString(rand.Next(0, 100)));
            }
            //Close the outputFile
            outputFile.Close();
        }
    }
}
