﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Actions;

/**
* 9/13/21
* CSC 253
* Garrett Davis
* This program will take the user's input for how many numbers they would like written to the file, then generate that many random  numbers between 1-100
* in the File named RandomNumberText.txt
*/

namespace RandomNumberFileWriter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void InputButton_Click(object sender, EventArgs e)
        {
            //Use a try catch for our streamWriter to ensure we don't have any issues
            try
            {
                //set the user's input to string _howmanyNumbers
                string _howManyNumbers = inputBox.Text;
                //convert _howmanyNumbers string to howManyNumbers int
                int howManyNumbers = int.Parse(_howManyNumbers);
                //call our createrandomNumberText method with our howManyNumbers int variables
                RandomNumberGenerator.CreateRandomNumberText(howManyNumbers);
                //Show the user the numbers have been entered into a file
                MessageBox.Show("The numbers have been written to the file");
            }
            //catch our potential issues
            catch (Exception ex)
            //show our exception method
            { MessageBox.Show(ex.Message); }

        }
        //close button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
