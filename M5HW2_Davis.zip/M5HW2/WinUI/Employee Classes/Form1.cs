﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeData;

namespace Employee_Classes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //exit button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //button to create a productionWorker
        private void CreateEmployeeButton_Click(object sender, EventArgs e)
        {
            string name = nameTextBox.Text;
            int employeeNumber;
            int.TryParse(employeeNumberTextBox.Text, out employeeNumber);
            int shiftNumber;
            int.TryParse(shiftNumberTextBox.Text, out shiftNumber);
            double payRate;
            double.TryParse(hourlyPayTexBox.Text, out payRate);
            ProductionWorker input = new ProductionWorker(shiftNumber, payRate, name, employeeNumber);

            outputBox.Text = input.Name + " " + input.EmployeeNumber + " " + input.ShiftNumber + " " + input.PayRate;

            
        }
        //clear text button
        private void ClearButton_Click(object sender, EventArgs e)
        {
            nameTextBox.Text = "";
            employeeNumberTextBox.Text = "";
            shiftNumberTextBox.Text = "";
            hourlyPayTexBox.Text = "";
        }
        //create shift supervisor button
        private void CreateShiftSupervisorButton_Click_1(object sender, EventArgs e)
        {
            string name = nameTextBox.Text;
            int employeeNumber;
            int.TryParse(employeeNumberTextBox.Text, out employeeNumber);
            double annualBonus;
            double.TryParse(annualBonusTextBox.Text, out annualBonus);
            ShiftSupervisor input = new ShiftSupervisor(annualBonus, name, employeeNumber);

            outputBox.Text = input.Name + " " + input.EmployeeNumber + " " + input.AnnualBonus;

        }
    }
}
