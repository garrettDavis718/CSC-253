﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Classes
{
    static class Program
    {
        /**
        * 10/24/2021
        * CSC 253
        * Garrett Davis
        * M5HW1 and M5HW2, an application that will create either a shiftsupervisor or productionworker object
        * and display it to the user
        */
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
