﻿
namespace PopulationDatabase
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cityBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cityBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cityDataGridView = new System.Windows.Forms.DataGridView();
            this.AddCity = new System.Windows.Forms.Button();
            this.DeleteCity = new System.Windows.Forms.Button();
            this.EditCity = new System.Windows.Forms.Button();
            this.SortPopAsc = new System.Windows.Forms.Button();
            this.SortPopDesc = new System.Windows.Forms.Button();
            this.SortCityNames = new System.Windows.Forms.Button();
            this.TotalPop = new System.Windows.Forms.Button();
            this.AvgPop = new System.Windows.Forms.Button();
            this.MaxPop = new System.Windows.Forms.Button();
            this.MinPop = new System.Windows.Forms.Button();
            this.ShowAllButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.newNameTextBox = new System.Windows.Forms.TextBox();
            this.newPopTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nameToEditTextBox = new System.Windows.Forms.TextBox();
            this.editedNameTextBox = new System.Windows.Forms.TextBox();
            this.editedPopulationTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.deletedCityTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.populationDBDataSet = new PopulationDatabase.PopulationDBDataSet();
            this.cityTableAdapter = new PopulationDatabase.PopulationDBDataSetTableAdapters.CityTableAdapter();
            this.tableAdapterManager = new PopulationDatabase.PopulationDBDataSetTableAdapters.TableAdapterManager();
            this.popToDeleteTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.popToEditTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingNavigator)).BeginInit();
            this.cityBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cityDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // cityBindingNavigator
            // 
            this.cityBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.cityBindingNavigator.BindingSource = this.cityBindingSource;
            this.cityBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.cityBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.cityBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.cityBindingNavigatorSaveItem});
            this.cityBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.cityBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.cityBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.cityBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.cityBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.cityBindingNavigator.Name = "cityBindingNavigator";
            this.cityBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.cityBindingNavigator.Size = new System.Drawing.Size(489, 25);
            this.cityBindingNavigator.TabIndex = 0;
            this.cityBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // cityBindingNavigatorSaveItem
            // 
            this.cityBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cityBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("cityBindingNavigatorSaveItem.Image")));
            this.cityBindingNavigatorSaveItem.Name = "cityBindingNavigatorSaveItem";
            this.cityBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.cityBindingNavigatorSaveItem.Text = "Save Data";
            this.cityBindingNavigatorSaveItem.Click += new System.EventHandler(this.cityBindingNavigatorSaveItem_Click);
            // 
            // cityDataGridView
            // 
            this.cityDataGridView.AutoGenerateColumns = false;
            this.cityDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cityDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.cityDataGridView.DataSource = this.cityBindingSource;
            this.cityDataGridView.Location = new System.Drawing.Point(12, 39);
            this.cityDataGridView.Name = "cityDataGridView";
            this.cityDataGridView.Size = new System.Drawing.Size(245, 557);
            this.cityDataGridView.TabIndex = 1;
            // 
            // AddCity
            // 
            this.AddCity.Location = new System.Drawing.Point(322, 12);
            this.AddCity.Name = "AddCity";
            this.AddCity.Size = new System.Drawing.Size(75, 47);
            this.AddCity.TabIndex = 2;
            this.AddCity.Text = "Add New City";
            this.AddCity.UseVisualStyleBackColor = true;
            this.AddCity.Click += new System.EventHandler(this.AddCity_Click);
            // 
            // DeleteCity
            // 
            this.DeleteCity.Location = new System.Drawing.Point(322, 220);
            this.DeleteCity.Name = "DeleteCity";
            this.DeleteCity.Size = new System.Drawing.Size(75, 32);
            this.DeleteCity.TabIndex = 3;
            this.DeleteCity.Text = "Delete City";
            this.DeleteCity.UseVisualStyleBackColor = true;
            this.DeleteCity.Click += new System.EventHandler(this.DeleteCity_Click);
            // 
            // EditCity
            // 
            this.EditCity.Location = new System.Drawing.Point(322, 106);
            this.EditCity.Name = "EditCity";
            this.EditCity.Size = new System.Drawing.Size(75, 30);
            this.EditCity.TabIndex = 4;
            this.EditCity.Text = "Edit City";
            this.EditCity.UseVisualStyleBackColor = true;
            this.EditCity.Click += new System.EventHandler(this.EditCity_Click);
            // 
            // SortPopAsc
            // 
            this.SortPopAsc.Location = new System.Drawing.Point(282, 313);
            this.SortPopAsc.Name = "SortPopAsc";
            this.SortPopAsc.Size = new System.Drawing.Size(75, 57);
            this.SortPopAsc.TabIndex = 5;
            this.SortPopAsc.Text = "Sort Population (Ascending)";
            this.SortPopAsc.UseVisualStyleBackColor = true;
            this.SortPopAsc.Click += new System.EventHandler(this.SortPopAsc_Click);
            // 
            // SortPopDesc
            // 
            this.SortPopDesc.Location = new System.Drawing.Point(363, 313);
            this.SortPopDesc.Name = "SortPopDesc";
            this.SortPopDesc.Size = new System.Drawing.Size(75, 57);
            this.SortPopDesc.TabIndex = 6;
            this.SortPopDesc.Text = "Sort Population (Descending)";
            this.SortPopDesc.UseVisualStyleBackColor = true;
            this.SortPopDesc.Click += new System.EventHandler(this.SortPopDesc_Click);
            // 
            // SortCityNames
            // 
            this.SortCityNames.Location = new System.Drawing.Point(322, 376);
            this.SortCityNames.Name = "SortCityNames";
            this.SortCityNames.Size = new System.Drawing.Size(75, 40);
            this.SortCityNames.TabIndex = 7;
            this.SortCityNames.Text = "Sort By Names";
            this.SortCityNames.UseVisualStyleBackColor = true;
            this.SortCityNames.Click += new System.EventHandler(this.SortCityNames_Click);
            // 
            // TotalPop
            // 
            this.TotalPop.Location = new System.Drawing.Point(282, 422);
            this.TotalPop.Name = "TotalPop";
            this.TotalPop.Size = new System.Drawing.Size(75, 36);
            this.TotalPop.TabIndex = 8;
            this.TotalPop.Text = "Total of Populations";
            this.TotalPop.UseVisualStyleBackColor = true;
            this.TotalPop.Click += new System.EventHandler(this.TotalPop_Click);
            // 
            // AvgPop
            // 
            this.AvgPop.Location = new System.Drawing.Point(363, 422);
            this.AvgPop.Name = "AvgPop";
            this.AvgPop.Size = new System.Drawing.Size(75, 36);
            this.AvgPop.TabIndex = 9;
            this.AvgPop.Text = "Average Population";
            this.AvgPop.UseVisualStyleBackColor = true;
            this.AvgPop.Click += new System.EventHandler(this.AvgPop_Click);
            // 
            // MaxPop
            // 
            this.MaxPop.Location = new System.Drawing.Point(322, 469);
            this.MaxPop.Name = "MaxPop";
            this.MaxPop.Size = new System.Drawing.Size(75, 45);
            this.MaxPop.TabIndex = 10;
            this.MaxPop.Text = "Highest Population";
            this.MaxPop.UseVisualStyleBackColor = true;
            this.MaxPop.Click += new System.EventHandler(this.MaxPop_Click);
            // 
            // MinPop
            // 
            this.MinPop.Location = new System.Drawing.Point(322, 510);
            this.MinPop.Name = "MinPop";
            this.MinPop.Size = new System.Drawing.Size(75, 43);
            this.MinPop.TabIndex = 11;
            this.MinPop.Text = "Lowest Population";
            this.MinPop.UseVisualStyleBackColor = true;
            this.MinPop.Click += new System.EventHandler(this.MinPop_Click);
            // 
            // ShowAllButton
            // 
            this.ShowAllButton.Location = new System.Drawing.Point(322, 559);
            this.ShowAllButton.Name = "ShowAllButton";
            this.ShowAllButton.Size = new System.Drawing.Size(75, 23);
            this.ShowAllButton.TabIndex = 12;
            this.ShowAllButton.Text = "Show All";
            this.ShowAllButton.UseVisualStyleBackColor = true;
            this.ShowAllButton.Click += new System.EventHandler(this.ShowAllButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(322, 588);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 13;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // newNameTextBox
            // 
            this.newNameTextBox.Location = new System.Drawing.Point(290, 80);
            this.newNameTextBox.Name = "newNameTextBox";
            this.newNameTextBox.Size = new System.Drawing.Size(67, 20);
            this.newNameTextBox.TabIndex = 14;
            // 
            // newPopTextBox
            // 
            this.newPopTextBox.Location = new System.Drawing.Point(363, 80);
            this.newPopTextBox.Name = "newPopTextBox";
            this.newPopTextBox.Size = new System.Drawing.Size(67, 20);
            this.newPopTextBox.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(269, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "*New City Name*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(360, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "*New City Population*";
            // 
            // nameToEditTextBox
            // 
            this.nameToEditTextBox.Location = new System.Drawing.Point(272, 155);
            this.nameToEditTextBox.Name = "nameToEditTextBox";
            this.nameToEditTextBox.Size = new System.Drawing.Size(75, 20);
            this.nameToEditTextBox.TabIndex = 18;
            // 
            // editedNameTextBox
            // 
            this.editedNameTextBox.Location = new System.Drawing.Point(272, 194);
            this.editedNameTextBox.Name = "editedNameTextBox";
            this.editedNameTextBox.Size = new System.Drawing.Size(75, 20);
            this.editedNameTextBox.TabIndex = 19;
            // 
            // editedPopulationTextBox
            // 
            this.editedPopulationTextBox.Location = new System.Drawing.Point(394, 194);
            this.editedPopulationTextBox.Name = "editedPopulationTextBox";
            this.editedPopulationTextBox.Size = new System.Drawing.Size(75, 20);
            this.editedPopulationTextBox.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(269, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "*City to Change*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(269, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "*Edited Name*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(384, 178);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "*Edited Population*";
            // 
            // deletedCityTextBox
            // 
            this.deletedCityTextBox.Location = new System.Drawing.Point(263, 274);
            this.deletedCityTextBox.Name = "deletedCityTextBox";
            this.deletedCityTextBox.Size = new System.Drawing.Size(100, 20);
            this.deletedCityTextBox.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(275, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "*City To Delete*";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "City";
            this.dataGridViewTextBoxColumn1.HeaderText = "City";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Population";
            this.dataGridViewTextBoxColumn2.HeaderText = "Population";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.populationDBDataSet;
            // 
            // populationDBDataSet
            // 
            this.populationDBDataSet.DataSetName = "PopulationDBDataSet";
            this.populationDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CityTableAdapter = this.cityTableAdapter;
            this.tableAdapterManager.UpdateOrder = PopulationDatabase.PopulationDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // popToDeleteTextBox
            // 
            this.popToDeleteTextBox.Location = new System.Drawing.Point(369, 274);
            this.popToDeleteTextBox.Name = "popToDeleteTextBox";
            this.popToDeleteTextBox.Size = new System.Drawing.Size(100, 20);
            this.popToDeleteTextBox.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(363, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "*Population To Delete*";
            // 
            // popToEditTextBox
            // 
            this.popToEditTextBox.Location = new System.Drawing.Point(394, 155);
            this.popToEditTextBox.Name = "popToEditTextBox";
            this.popToEditTextBox.Size = new System.Drawing.Size(75, 20);
            this.popToEditTextBox.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(377, 139);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "*Population to Change*";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 623);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.popToEditTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.popToDeleteTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.deletedCityTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.editedPopulationTextBox);
            this.Controls.Add(this.editedNameTextBox);
            this.Controls.Add(this.nameToEditTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.newPopTextBox);
            this.Controls.Add(this.newNameTextBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ShowAllButton);
            this.Controls.Add(this.MinPop);
            this.Controls.Add(this.MaxPop);
            this.Controls.Add(this.AvgPop);
            this.Controls.Add(this.TotalPop);
            this.Controls.Add(this.SortCityNames);
            this.Controls.Add(this.SortPopDesc);
            this.Controls.Add(this.SortPopAsc);
            this.Controls.Add(this.EditCity);
            this.Controls.Add(this.DeleteCity);
            this.Controls.Add(this.AddCity);
            this.Controls.Add(this.cityDataGridView);
            this.Controls.Add(this.cityBindingNavigator);
            this.Name = "Form1";
            this.Text = "Population Database";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingNavigator)).EndInit();
            this.cityBindingNavigator.ResumeLayout(false);
            this.cityBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cityDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PopulationDBDataSet populationDBDataSet;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private PopulationDBDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private PopulationDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator cityBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton cityBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView cityDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button AddCity;
        private System.Windows.Forms.Button DeleteCity;
        private System.Windows.Forms.Button EditCity;
        private System.Windows.Forms.Button SortPopAsc;
        private System.Windows.Forms.Button SortPopDesc;
        private System.Windows.Forms.Button SortCityNames;
        private System.Windows.Forms.Button TotalPop;
        private System.Windows.Forms.Button AvgPop;
        private System.Windows.Forms.Button MaxPop;
        private System.Windows.Forms.Button MinPop;
        private System.Windows.Forms.Button ShowAllButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.TextBox newNameTextBox;
        private System.Windows.Forms.TextBox newPopTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nameToEditTextBox;
        private System.Windows.Forms.TextBox editedNameTextBox;
        private System.Windows.Forms.TextBox editedPopulationTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox deletedCityTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox popToDeleteTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox popToEditTextBox;
        private System.Windows.Forms.Label label8;
    }
}

