﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 10/7/21
* CSC 253
* Garrett Davis
* Program will edit the populationDbDataset in various way with input from the user
*/

namespace PopulationDatabase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

  

        private void AddCity_Click(object sender, EventArgs e)
        {
            int population;
            string name = newNameTextBox.Text;
            int.TryParse(newPopTextBox.Text, out population);
            try
            {
                this.cityTableAdapter.InsertQuery(name, population);
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }

        private void DeleteCity_Click(object sender, EventArgs e)
        {
            int pop;
            int.TryParse(popToDeleteTextBox.Text, out pop);
            try
            {
                this.cityTableAdapter.DeleteQuery(deletedCityTextBox.Text, pop);
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void EditCity_Click(object sender, EventArgs e)
        {
            double oldPop;
            double newPop;
            double.TryParse(popToEditTextBox.Text, out oldPop);
            double.TryParse(editedPopulationTextBox.Text, out newPop);
            try
            {
                this.cityTableAdapter.UpdateQuery(editedNameTextBox.Text, newPop, nameToEditTextBox.Text, oldPop);
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }
        private void SortPopAsc_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.SortPopAsc(this.populationDBDataSet.City);
        }

        private void SortPopDesc_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.SortPopDesc(this.populationDBDataSet.City);
        }

        private void SortCityNames_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.SortCityAsc(this.populationDBDataSet.City);
        }

        private void TotalPop_Click(object sender, EventArgs e)
        {

            string output = this.cityTableAdapter.SumPopulation().ToString();
            MessageBox.Show(output);
            
            
        }

        private void AvgPop_Click(object sender, EventArgs e)
        {
            string output = this.cityTableAdapter.AvgPop().ToString();
            MessageBox.Show(output);
        }

        private void MaxPop_Click(object sender, EventArgs e)
        {
            string output = this.cityTableAdapter.MaxPop().ToString();
            MessageBox.Show(output);
        }

        private void MinPop_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this.cityTableAdapter.MinPop().ToString());
        }

        private void ShowAllButton_Click(object sender, EventArgs e)
        {
           this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
