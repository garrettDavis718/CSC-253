﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Pet
    {
        //initialize the constructor the for the pet class
        public Pet(string name, string type, decimal age)
        {
            Name = name;
            Type = type;
            Age = age; 
        }
        public Pet(string name)
        {
            Name = name;
            Type = "";
            Age = 0;
        }
        public Pet()
        {
            Name = "";
            Type = "";
            Age = 0;
        }
        //Creat the properties for our constuctor
        public string Name { get; set; }
        public string Type { get; set; }
        //We use a decimal here in order to compensate for partial year entries
        public decimal Age { get; set; }
    }
}
