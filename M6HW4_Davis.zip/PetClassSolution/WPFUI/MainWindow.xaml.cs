﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary;

namespace WPFUI
{
        /**
        * 11/21/21
        * CSC 253
        * Garrett Davis
        * This program will WPF to create and display pet objects
        */
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void EnterPet_Click(object sender, RoutedEventArgs e)
        {
            string name;
            decimal age;
            string type;

            name = NameBox.Text;
            decimal.TryParse(AgeBox.Text, out age);
            type = TypeBox.Text;

            Pet input = new Pet(name, type, age);
            PetBox.Items.Add(input.Name + " " + input.Type + " " + input.Age);
        }

        private void ClearText_Click(object sender, RoutedEventArgs e)
        {
            NameBox.Clear();
            AgeBox.Clear();
            TypeBox.Clear();
            PetBox.Items.Clear();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
