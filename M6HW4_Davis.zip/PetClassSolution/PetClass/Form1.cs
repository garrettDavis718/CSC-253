﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace PetClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Create pet variable 
        Pet pet;
        private void GetInputButton_Click(object sender, EventArgs e)
        {
            //Setting our properties
            string name = NameTxt.Text;
            string type = TypeTxt.Text;
            //Need to verify age is indeed input as a decimal
            decimal age = 0.0m;

            //Verifying Information is input and TryParsing our decimal
            if (!string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(type) && decimal.TryParse(AgeTxt.Text, out age))
            {
                pet = new Pet(name, type, age);
            }
            else
            {
                MessageBox.Show("Please correct your input", "Invalid Input");
            }
            

        }

        private void OutputButton_Click(object sender, EventArgs e)
        {

            //We create a try/catch so that we can keep the user from trying to prompt an output without inputting information
            try
            {
                OutputBox.Items.Add("Pet's name: " + pet.Name);
                OutputBox.Items.Add("Pet's type: " + pet.Type);
                OutputBox.Items.Add("Pets age: " + pet.Age);

            }
            catch (NullReferenceException)//"NullReferenceException" verifies that we have reference
            {
                MessageBox.Show("Please enter data first");
            }
           
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
