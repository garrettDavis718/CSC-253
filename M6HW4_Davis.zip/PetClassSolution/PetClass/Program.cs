﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PetClass
{
    static class Program
    {
        /**
         * 3/7/2021
         * CSC 153
         * Garrett Davis
         * This Program will take accept the user's input for different properties of the pet class(name, type, and age)
         * and display them back to the them.
         */
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
 
        }
    }
}
