﻿namespace PetClass
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.NameTxt = new System.Windows.Forms.TextBox();
            this.TypeTxt = new System.Windows.Forms.TextBox();
            this.AgeTxt = new System.Windows.Forms.TextBox();
            this.GetInputButton = new System.Windows.Forms.Button();
            this.OutputButton = new System.Windows.Forms.Button();
            this.StopButton = new System.Windows.Forms.Button();
            this.OutputBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(52, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pet Name";
            this.label1.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(52, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pet Type";
            this.label2.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(52, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Pet Age";
            this.label3.UseWaitCursor = true;
            // 
            // NameTxt
            // 
            this.NameTxt.Location = new System.Drawing.Point(170, 50);
            this.NameTxt.Name = "NameTxt";
            this.NameTxt.Size = new System.Drawing.Size(128, 20);
            this.NameTxt.TabIndex = 3;
            this.NameTxt.UseWaitCursor = true;
            // 
            // TypeTxt
            // 
            this.TypeTxt.Location = new System.Drawing.Point(170, 100);
            this.TypeTxt.Name = "TypeTxt";
            this.TypeTxt.Size = new System.Drawing.Size(128, 20);
            this.TypeTxt.TabIndex = 4;
            this.TypeTxt.UseWaitCursor = true;
            // 
            // AgeTxt
            // 
            this.AgeTxt.Location = new System.Drawing.Point(170, 150);
            this.AgeTxt.Name = "AgeTxt";
            this.AgeTxt.Size = new System.Drawing.Size(128, 20);
            this.AgeTxt.TabIndex = 5;
            this.AgeTxt.UseWaitCursor = true;
            // 
            // GetInputButton
            // 
            this.GetInputButton.Location = new System.Drawing.Point(50, 244);
            this.GetInputButton.Name = "GetInputButton";
            this.GetInputButton.Size = new System.Drawing.Size(81, 22);
            this.GetInputButton.TabIndex = 8;
            this.GetInputButton.Text = "Enter Data";
            this.GetInputButton.UseVisualStyleBackColor = true;
            this.GetInputButton.UseWaitCursor = true;
            this.GetInputButton.Click += new System.EventHandler(this.GetInputButton_Click);
            // 
            // OutputButton
            // 
            this.OutputButton.Location = new System.Drawing.Point(137, 244);
            this.OutputButton.Name = "OutputButton";
            this.OutputButton.Size = new System.Drawing.Size(94, 22);
            this.OutputButton.TabIndex = 9;
            this.OutputButton.Text = "Display Pet Data";
            this.OutputButton.UseVisualStyleBackColor = true;
            this.OutputButton.UseWaitCursor = true;
            this.OutputButton.Click += new System.EventHandler(this.OutputButton_Click);
            // 
            // StopButton
            // 
            this.StopButton.Location = new System.Drawing.Point(237, 244);
            this.StopButton.Name = "StopButton";
            this.StopButton.Size = new System.Drawing.Size(75, 23);
            this.StopButton.TabIndex = 10;
            this.StopButton.Text = "Exit";
            this.StopButton.UseVisualStyleBackColor = true;
            this.StopButton.UseWaitCursor = true;
            this.StopButton.Click += new System.EventHandler(this.StopButton_Click);
            // 
            // OutputBox
            // 
            this.OutputBox.FormattingEnabled = true;
            this.OutputBox.Location = new System.Drawing.Point(50, 272);
            this.OutputBox.Name = "OutputBox";
            this.OutputBox.Size = new System.Drawing.Size(262, 95);
            this.OutputBox.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 395);
            this.Controls.Add(this.OutputBox);
            this.Controls.Add(this.StopButton);
            this.Controls.Add(this.OutputButton);
            this.Controls.Add(this.GetInputButton);
            this.Controls.Add(this.AgeTxt);
            this.Controls.Add(this.TypeTxt);
            this.Controls.Add(this.NameTxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Pet Class";
            this.UseWaitCursor = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NameTxt;
        private System.Windows.Forms.TextBox TypeTxt;
        private System.Windows.Forms.TextBox AgeTxt;
        private System.Windows.Forms.Button GetInputButton;
        private System.Windows.Forms.Button OutputButton;
        private System.Windows.Forms.Button StopButton;
        private System.Windows.Forms.ListBox OutputBox;
    }
}

