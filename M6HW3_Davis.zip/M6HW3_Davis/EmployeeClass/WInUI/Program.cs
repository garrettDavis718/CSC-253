﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WInUI
{
    static class Program
    {
        /**
        * 11/21/21
        * CSC 253
        * Garrett Davis
        * This program will utillize windows forms to create and display employee objects
        */
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
