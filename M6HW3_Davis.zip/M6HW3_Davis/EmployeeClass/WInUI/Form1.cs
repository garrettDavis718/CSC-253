﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using People;

namespace WInUI
{
    public partial class Form1 : Form
    {

        public Form1()
        {

            InitializeComponent();
            
        }

        private void EnterBtn_Click(object sender, EventArgs e)
        {
            string name;
            int idNumber;
            string position;
            string department;

            name = NameBox.Text;
            int.TryParse(IDBox.Text, out idNumber);
            position = PositionBox.Text;
            department = DepartmentBox.Text;

            Employee input = new Employee(name, idNumber, department, position);
            EmployeesBox.Items.Add(input.Name + " " + input.IdNumber + " " + input.Department + " " + input.Position);

        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            EmployeesBox.Items.Clear();
            NameBox.Clear();
            IDBox.Clear();
            PositionBox.Clear();
            DepartmentBox.Clear();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
