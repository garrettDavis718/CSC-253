﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Actions
{
    //StreamWriter class
    public class Writer
    {
        //method to write the lists.people to a csv
        public static string WritePeopleToFile()
        {
            //init our streamwriter object
            StreamWriter outputFile;
            //try catch
            try
            {
                //open file
                outputFile = File.CreateText("people.csv");
                //foreachloop to go through the lists.people list, writeline everytime to make new line
                foreach (Person Person in Lists.People)
                {
                    //output the paramaters
                    outputFile.WriteLine($"{Person.FirstName}, {Person.LastName}, {Person.Age}");
                }
                //close file
                outputFile.Close();
                //return string for success
                return "saved";
            }
            //catch exception and return message
            catch (Exception ex)
            {
                string message = ex.Message;
                return message;
            }
        }
    }
}
