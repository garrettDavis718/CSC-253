﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actions
{
    public static class ListBuilder
    {
        //List builder class that houses our List building method
        //method will take input of person's parameters and input them into the list
        public static void AddToList(string firstName, string lastName, int age)
        {
            Lists.People.Add(new Person(firstName, lastName, age));
        }
    }
}
