﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actions
{
    //lists class to hold our list
    public static class Lists
    {
        public static List<Person> People = new List<Person>();
    }
}
