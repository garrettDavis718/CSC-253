﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actions
{
    public static class Validation
    {
        //Validation class with a method to check each character in a string for being a digit
        public static bool CheckIfNumeral(string input)
        {
            //init bool
            bool pass = false;
            //trim input
            input.Trim();
            //foreach char in the input check if it's a digit, if it is return true, otherwise return false
            foreach (char num in input)
            {
                if (char.IsDigit(num))
                {
                    pass = true;
                    
                }
                else 
                { pass = false;  }
            }
            //return the results
            return pass;
        }
    }
}
