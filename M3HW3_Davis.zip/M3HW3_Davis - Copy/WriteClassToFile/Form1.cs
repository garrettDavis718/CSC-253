﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Actions;
/**
*09/23/2021
* CSC 253
* Garrett Davis 
* This program will read the user's input and attempt to create a person 
* object out of them, and then add that person to the "people" list.
* The program will then output the list to the file "people.csv"
*/

namespace WriteClassToFile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //input button, this button will attempt to create the Person object with the information provided by the User

        private void InputButton_Click(object sender, EventArgs e)
        {
            //if statement that will check each textBox for input
            if (string.IsNullOrEmpty(FirstBox.Text))
            {
                //Tell the user they need to input more info
                MessageBox.Show("You left the first name box empty!");
            }
            else if (string.IsNullOrEmpty(LastBox.Text))
            {

                MessageBox.Show("You have left the last name box empty!");
            }
            else if (string.IsNullOrEmpty(AgeBox.Text))
            {

                MessageBox.Show("You have left the age box empty!");
            }
            //Last bit of validation references a validation class I created in order to check strings for numeric input
            else if (Validation.CheckIfNumeral(AgeBox.Text) == false)
            { MessageBox.Show("You need to enter only a number in the age box!"); }
            //Actually create the object and input it to our Lists.people list after all validation is done
            else
            {
                int age;
                string firstName = FirstBox.Text;
                string lastName = LastBox.Text;
                int.TryParse(AgeBox.Text, out age);
                //Call our listbuilder method to add our user's input object
                ListBuilder.AddToList(firstName, lastName, age);
                //Clear the preview box at the beginning to avoid having redundant info on the preview box
                PreviewBox.Items.Clear();
                //foreach loop that will add each person's name from the people list to the previewBox
                foreach (Person person in Lists.People)
                { PreviewBox.Items.Add(person.FirstName); }
            }

        }
        //CLear Button for clearing textboxes
        private void ClearButton_Click(object sender, EventArgs e)
        {
            FirstBox.Clear();
            LastBox.Clear();
            AgeBox.Clear();
            PreviewBox.Items.Clear();
        }
        //Write File button for writing everything to a file, includes my preview box for showing the user what they're saving

        private void WriteFileButton_Click(object sender, EventArgs e)
        {
           
            //Get the return message from the WritePeopleToFile method so we can let the user know what has happened
            string message = Writer.WritePeopleToFile();
            MessageBox.Show(message);
        }
        //close button
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
