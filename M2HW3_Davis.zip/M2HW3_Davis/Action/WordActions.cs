﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Action
{
    public class WordActions
    {
        //static method for finding the most common letter in a give string, returns the char
        public static char MostCommonLetter(string input)
        {
            //initialize array charCount to a size of 256(this is the the size of the entire ASCII library, so we should never be out of bounds)
            //this list holds integers because we want the amount of each character held in the array, not the actual char
            int[] charCount = new int[256];
            //create an integer to hold the length of the string
            int length = input.Length;
            //For loop that will go through each char in the given string
            for (int i = 0; i < length; i++)
            {
                //this if statment will check if the given character is a letter or a digit, to ensure we're not counting the spaces or punctuation
                if (char.IsLetterOrDigit(input[i]))
                {
                    //we increment the specific element input[i] in the array charCount, this will keep track of how many of each character is in the string
                    charCount[input[i]]++;
                }

            }
            //init maxCount and set it to -1 to ensure that each element is checked
            int maxCount = -1;
            //init maxChar char and set it to an empty space as a placeholder, this should always end up as a letter or digit
            char maxChar = ' ';
            //for loop that will go through each element in our charCounta array and compare it to our current our current highest
            //highest count of a single character
            for (int i = 0; i < length; i++)
            {
                //if statement that compares our current maxCount int to the int associated with the element input[i]
                if (maxCount < charCount[input[i]])
                {
                    //maxCount gets set to the same number as the current int as it is higher than it and becomes the new max
                    maxCount = charCount[input[i]];
                    //maxChar is set to the char of the previous int from the charCount list (input[i])
                    maxChar = input[i];
                }
            }
            //return our maxChar
            return maxChar;
        }
            
    }
}
