﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Action;
using System.Windows.Forms;

/**
* 9/12/21
* CSC 253
* Garrett Davis
* This program check for input for the user in the given textbox,
* and return the most common letter or digit that it contains.
*/

namespace AverageNumberOfLetters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //button for user to click after they've put something in the text box
        private void InputButton_Click(object sender, EventArgs e)
        {
            //check if string is null or empty
            if (!string.IsNullOrEmpty(InputBox.Text))
            {
                //Set our most common letter label(avgLbl) to the most common letter in the string, using our method from actions
                //(we're also converting it to string for it to be able to go into the label)
                AvgLbl.Text = char.ToString(WordActions.MostCommonLetter(InputBox.Text));
            }
            else
            //else messageBox if the inputBox is left empty
            { MessageBox.Show("Please enter something in the text box."); }
        }
        //Button for clearing the textbox and labl
        private void ClearButton_Click(object sender, EventArgs e)
        {
            InputBox.Text = "";
            AvgLbl.Text = "";
        }
        //Close program

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
