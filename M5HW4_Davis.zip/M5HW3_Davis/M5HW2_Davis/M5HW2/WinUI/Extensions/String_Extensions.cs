﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensions
{
    public static class String_Extensions
    {
            public static char[] ConvertToArray(this string input)
            {
                char[] inputArray = new char[input.Length];
                inputArray = input.ToCharArray();
                return inputArray;
            }
            public static string[] ConvertToDate(this string input)
            {
                string[] inputArray = new string[3];
                char delimiter = '/';
                inputArray = input.Split(delimiter);
                return inputArray;
            }
            public static string ConvertToPhone(this string input)
            {
            string output = "";
            if (input.Length == 10)
                {
                output += '(';
                int i = 1;
                foreach (char c in input)
                {
                    output += c;
                    if (i == 3)
                    {
                        output += ')';
                    }
                    else if (i == 6)
                    {
                        output += '-';
                    }
                    i++;
                }
                }
               else
                {
                  output = "number incorrect length";
                }
            return output;
            }
            public static string Backwards(this string input)
            {
            char[] inputArray = input.ToCharArray();
            string reverse = "";
            for (int i = inputArray.Length - 1; i > -1; i--)
            {
                reverse += inputArray[i];
            }
            return reverse;
            }
            public static int Count(this string input)
            {
            char delimiter = ' ';
            string[] inputArray = input.Split(delimiter);
            int count = inputArray.Length;
            return count;
            }
    }
}
