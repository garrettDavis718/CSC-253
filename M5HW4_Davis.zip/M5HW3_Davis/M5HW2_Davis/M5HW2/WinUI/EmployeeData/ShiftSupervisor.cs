﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeData
{
    //Shift supervisor class that is derived from the employee class
    public class ShiftSupervisor : Employee 
    {
        //AnnualBonus is the only unique property to ShiftSupervisor
        public double AnnualBonus { get; set; }
        //Constructor for shiftSupervisor
        public ShiftSupervisor(double annualBonus, string name, int employeeNumber) 
            : base (name, employeeNumber)
        {
            AnnualBonus = annualBonus;
        }
        //default constructor
        public ShiftSupervisor()
        { }
    }
}
