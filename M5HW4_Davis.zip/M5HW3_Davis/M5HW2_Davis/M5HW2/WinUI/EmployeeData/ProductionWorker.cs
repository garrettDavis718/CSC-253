﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeData
{
    //Productionworker class derived from employee class
    public class ProductionWorker : Employee
    {
        public int ShiftNumber { get; set; }
        public double PayRate { get; set; }
        public ProductionWorker(int shiftNumber, double payRate, string name, int employeeNumber)
            : base(name, employeeNumber)
        {
            ShiftNumber = shiftNumber;
            PayRate = payRate;
        }
        //default constructor
        public ProductionWorker()
        { }
    }
}
