﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeData
{
    //Employee Parent class, used in creation of all subsequent employee classes
    public class Employee
    {
        public string Name { get; set; }
        public int EmployeeNumber { get; set; }
        public Employee(string name, int employeeNumber)
        {
            Name = name;
            EmployeeNumber = employeeNumber;
        }
        public Employee()
        { }

    }
}
