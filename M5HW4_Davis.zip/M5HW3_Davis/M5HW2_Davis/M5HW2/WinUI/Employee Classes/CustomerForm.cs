﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeData;
using Extensions;

namespace Employee_Classes
{
    public partial class CustomerForm : Form
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void EnterBtn_Click(object sender, EventArgs e)
        {
            
            string name = nameTxtBox.Text;
            string address = addresstxtBox.Text;
            string phone = phoneTxtBox.Text.ConvertToPhone();
            int custNumber;
            int.TryParse(custNumbTxtBox.Text, out custNumber);
            bool mail = mailCheckBox.Checked;
            Customer input = new Customer(name, address, phone, custNumber, mail);
            outputBox.Items.Add("Customer Name: " + input.PersonName);
            outputBox.Items.Add("Backwards Name: " + input.PersonName.Backwards());
            outputBox.Items.Add("Customer Address: " + input.Address);
            outputBox.Items.Add("Words counted from address: " + input.Address.Count());
            outputBox.Items.Add("Customer Phone Number: " + input.PhoneNumber);
            outputBox.Items.Add("Customer Number: " + input.CustomerNumber);
            outputBox.Items.Add("Customer Birthday Month: " + birthdayTxtBox.Text.ConvertToDate()[0]);
            outputBox.Items.Add("Customer Birthday Day: " + birthdayTxtBox.Text.ConvertToDate()[1]);
            outputBox.Items.Add("Customer Birthday Year: " + birthdayTxtBox.Text.ConvertToDate()[2]);
            outputBox.Items.Add("On Mail List: " + input.MailList);
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            nameTxtBox.Text = "";
            addresstxtBox.Text = "";
            phoneTxtBox.Text = "";
            custNumbTxtBox.Text = "";
            mailCheckBox.Checked = false;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            //hides this form and reopens form1
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.ShowDialog();
        }
    }
}
